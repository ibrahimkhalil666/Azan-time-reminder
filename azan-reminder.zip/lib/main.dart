import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:adhan/adhan.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tzdata;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones(); // Remove await from here
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Namaz Reminder',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: NamazReminder(),
    );
  }
}

class NamazReminder extends StatefulWidget {
  @override
  _NamazReminderState createState() => _NamazReminderState();
}

class _NamazReminderState extends State<NamazReminder> {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  PrayerTimes? _prayerTimes;

  @override
  void initState() {
    super.initState();
    _initializePrayerTimes();
    _initializeNotifications();
  }

  Future<void> _initializePrayerTimes() async {
    final today = DateTime.now();
    final coordinates =
        Coordinates(24.8607, 67.0011); // Change to your coordinates
    final params = CalculationMethod.karachi.getParameters();
    params.madhab = Madhab.hanafi;
    final prayerTimes = PrayerTimes(
      coordinates,
      DateComponents(today.year, today.month, today.day),
      params,
    );
    setState(() {
      _prayerTimes = prayerTimes;
    });
  }

  Future<void> _initializeNotifications() async {
    final initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    final initializationSettingsIOS = IOSInitializationSettings();
    final initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );
    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  Future<void> _scheduleNotification(
      String prayerName, DateTime dateTime) async {
    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'channel_id', // Provide your channel id
      'Namaz Reminder', // Provide your channel name
      'Reminders for Namaz times', // Provide your channel description
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
    );
    final iOSPlatformChannelSpecifics = IOSNotificationDetails();
    final platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iOSPlatformChannelSpecifics,
    );

    // Convert DateTime to TZDateTime
    final scheduledDate = tz.TZDateTime.from(dateTime, tz.local);

    await flutterLocalNotificationsPlugin.zonedSchedule(
      0,
      'Namaz Reminder',
      'Time for $prayerName prayer!',
      scheduledDate,
      platformChannelSpecifics,
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Widget _buildPrayerTimeCard(String title, DateTime time) {
    return Card(
      child: ListTile(
        title: Text(
          title,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${time.hour}:${time.minute}',
          style: TextStyle(fontSize: 16),
        ),
        onTap: () {
          _scheduleNotification(title, time);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Namaz Reminder'),
      ),
      body: Center(
        child: _prayerTimes != null
            ? Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    _buildPrayerTimeCard('Fajr', _prayerTimes!.fajr),
                    _buildPrayerTimeCard('Dhuhr', _prayerTimes!.dhuhr),
                    _buildPrayerTimeCard('Asr', _prayerTimes!.asr),
                    _buildPrayerTimeCard('Maghrib', _prayerTimes!.maghrib),
                    _buildPrayerTimeCard('Isha', _prayerTimes!.isha),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        _scheduleNotification('All prayers', DateTime.now());
                      },
                      child: Text('Set Reminders for All Prayers'),
                    ),
                  ],
                ),
              )
            : CircularProgressIndicator(),
      ),
    );
  }
}
