package com.example.helloo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
